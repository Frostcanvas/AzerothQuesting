local ADDON_NAME, ZQG = ...

local mainFrame = _G.ZoneQuestGuideFrame
if not mainFrame then
    return
end

-- Azeroth Questing uses one canonical frequency value internally regardless of
-- which WoW API supplied the quest metadata:
--   1 = normal/zone quest, 2 = daily, 3 = weekly.
local FREQUENCY_NORMAL = 1
local FREQUENCY_DAILY = 2
local FREQUENCY_WEEKLY = 3
local questFrequencies = {}

local function GetDB()
    ZoneQuestGuideDB = ZoneQuestGuideDB or {}
    return ZoneQuestGuideDB
end

local function CurrentMapID()
    if not C_Map or not C_Map.GetBestMapForUnit then
        return nil
    end
    return C_Map.GetBestMapForUnit("player")
end

local function MarkFrequency(questID, frequency)
    if not questID or questID <= 0 then
        return
    end
    if frequency == FREQUENCY_NORMAL or frequency == FREQUENCY_DAILY
        or frequency == FREQUENCY_WEEKLY then
        questFrequencies[questID] = frequency
    end
end

local function RefreshMapFrequencyCache()
    local mapID = CurrentMapID()
    if not mapID then
        return
    end

    if C_QuestLog and C_QuestLog.GetQuestsOnMap then
        local ok, quests = pcall(C_QuestLog.GetQuestsOnMap, mapID)
        if ok and type(quests) == "table" then
            for _, info in ipairs(quests) do
                if info.questID then
                    if info.isWeekly then
                        MarkFrequency(info.questID, FREQUENCY_WEEKLY)
                    elseif info.isDaily then
                        MarkFrequency(info.questID, FREQUENCY_DAILY)
                    end
                end
            end
        end
    end

    if C_QuestLine and C_QuestLine.GetAvailableQuestLines then
        local ok, lines = pcall(C_QuestLine.GetAvailableQuestLines, mapID)
        if ok and type(lines) == "table" then
            for _, info in ipairs(lines) do
                if info.questID then
                    if info.isWeekly then
                        MarkFrequency(info.questID, FREQUENCY_WEEKLY)
                    elseif info.isDaily then
                        MarkFrequency(info.questID, FREQUENCY_DAILY)
                    end
                end
            end
        end
    end
end

local function CaptureGossipFrequencies()
    if not C_GossipInfo then
        return
    end

    local getters = {
        C_GossipInfo.GetAvailableQuests,
        C_GossipInfo.GetActiveQuests,
    }

    for _, getter in ipairs(getters) do
        if getter then
            local ok, quests = pcall(getter)
            if ok and type(quests) == "table" then
                for _, info in ipairs(quests) do
                    -- GossipQuestUIInfo uses 1 normal, 2 daily, 3 weekly.
                    if info.questID and (info.frequency == FREQUENCY_NORMAL
                        or info.frequency == FREQUENCY_DAILY
                        or info.frequency == FREQUENCY_WEEKLY) then
                        MarkFrequency(info.questID, info.frequency)
                    end
                end
            end
        end
    end
end

local function QuestLogFrequency(questID)
    if not questID or not C_QuestLog or not C_QuestLog.GetLogIndexForQuestID
        or not C_QuestLog.GetInfo then
        return nil
    end

    local indexOK, logIndex = pcall(C_QuestLog.GetLogIndexForQuestID, questID)
    if not indexOK or not logIndex or logIndex <= 0 then
        return nil
    end

    local infoOK, info = pcall(C_QuestLog.GetInfo, logIndex)
    if not infoOK or not info or info.frequency == nil then
        return nil
    end

    if Enum and Enum.QuestFrequency then
        if Enum.QuestFrequency.Daily ~= nil and info.frequency == Enum.QuestFrequency.Daily then
            return FREQUENCY_DAILY
        end
        if Enum.QuestFrequency.Weekly ~= nil and info.frequency == Enum.QuestFrequency.Weekly then
            return FREQUENCY_WEEKLY
        end
        return FREQUENCY_NORMAL
    end

    -- Fallback for clients where the enum table is unavailable. Quest-log
    -- frequency has historically used 0 normal, 1 daily, 2 weekly.
    if info.frequency == 1 then
        return FREQUENCY_DAILY
    elseif info.frequency == 2 then
        return FREQUENCY_WEEKLY
    end
    return FREQUENCY_NORMAL
end

function ZQG.GetQuestFrequency(quest)
    if not quest or not quest.id then
        return FREQUENCY_NORMAL
    end

    if quest.questFrequency == FREQUENCY_NORMAL or quest.questFrequency == FREQUENCY_DAILY
        or quest.questFrequency == FREQUENCY_WEEKLY then
        return quest.questFrequency
    end

    local frequency = questFrequencies[quest.id]
    if not frequency and quest.accepted then
        frequency = QuestLogFrequency(quest.id)
        if frequency then
            MarkFrequency(quest.id, frequency)
        end
    end

    if not frequency then
        if quest.isWeekly then
            frequency = FREQUENCY_WEEKLY
        elseif quest.isDaily then
            frequency = FREQUENCY_DAILY
        else
            frequency = FREQUENCY_NORMAL
        end
    end

    quest.questFrequency = frequency
    quest.isDaily = frequency == FREQUENCY_DAILY
    quest.isWeekly = frequency == FREQUENCY_WEEKLY
    return frequency
end

function ZQG.IsDailyQuest(quest)
    return ZQG.GetQuestFrequency(quest) == FREQUENCY_DAILY
end

function ZQG.IsWeeklyQuest(quest)
    return ZQG.GetQuestFrequency(quest) == FREQUENCY_WEEKLY
end

function ZQG.IsRepeatableQuest(quest)
    local frequency = ZQG.GetQuestFrequency(quest)
    return frequency == FREQUENCY_DAILY or frequency == FREQUENCY_WEEKLY
end

function ZQG.GetQuestFrequencyBadge(quest)
    local frequency = ZQG.GetQuestFrequency(quest)
    if frequency == FREQUENCY_DAILY then
        return " [Daily]"
    elseif frequency == FREQUENCY_WEEKLY then
        return " [Weekly]"
    end
    return ""
end

function ZQG.GetQuestCategoryPriority(quest)
    return ZQG.GetQuestFrequency(quest) == FREQUENCY_NORMAL and 1 or 2
end

local function ActiveView()
    local DB = GetDB()
    if DB.questFrequencyView ~= "repeatable" then
        DB.questFrequencyView = "zone"
    end
    return DB.questFrequencyView
end

function ZQG.FilterQuestsForDisplay(quests)
    RefreshMapFrequencyCache()

    local view = ActiveView()
    local filtered = {}
    for _, quest in ipairs(quests or {}) do
        local frequency = ZQG.GetQuestFrequency(quest)
        local include = view == "zone" and frequency == FREQUENCY_NORMAL
            or view == "repeatable" and (frequency == FREQUENCY_DAILY or frequency == FREQUENCY_WEEKLY)
        if include then
            filtered[#filtered + 1] = quest
        end
    end
    return filtered
end

local function GetQuestRows()
    local rows = {}
    for _, child in ipairs({ mainFrame:GetChildren() }) do
        if child.GetObjectType and child:GetObjectType() == "Button"
            and child.text and child.text.SetText then
            local width, height = child:GetSize()
            if math.abs((width or 0) - 330) < 1 and math.abs((height or 0) - 25) < 1 then
                rows[#rows + 1] = child
            end
        end
    end

    table.sort(rows, function(a, b)
        local _, _, _, _, ay = a:GetPoint(1)
        local _, _, _, _, by = b:GetPoint(1)
        return (ay or 0) > (by or 0)
    end)
    return rows
end

local rows = GetQuestRows()
for index, row in ipairs(rows) do
    row:ClearAllPoints()
    row:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 14, -184 - ((index - 1) * 27))
end
mainFrame:SetHeight(475)

local zoneTab = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
zoneTab:SetSize(158, 24)
zoneTab:SetPoint("TOPLEFT", mainFrame, "TOPLEFT", 14, -151)
zoneTab:SetText("Zone Quests")

local repeatableTab = CreateFrame("Button", nil, mainFrame, "UIPanelButtonTemplate")
repeatableTab:SetSize(158, 24)
repeatableTab:SetPoint("LEFT", zoneTab, "RIGHT", 8, 0)
repeatableTab:SetText("Daily / Weekly")

local function UpdateTabs()
    local view = ActiveView()
    if view == "zone" then
        zoneTab:SetButtonState("PUSHED", true)
        repeatableTab:SetButtonState("NORMAL", false)
    else
        zoneTab:SetButtonState("NORMAL", false)
        repeatableTab:SetButtonState("PUSHED", true)
    end
end

local function SelectView(view)
    local DB = GetDB()
    DB.questFrequencyView = view
    UpdateTabs()
    if ZQG.Refresh then
        ZQG.Refresh()
    end
end

zoneTab:SetScript("OnClick", function() SelectView("zone") end)
repeatableTab:SetScript("OnClick", function() SelectView("repeatable") end)

local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_ENTERING_WORLD")
events:RegisterEvent("ZONE_CHANGED_NEW_AREA")
events:RegisterEvent("ZONE_CHANGED")
events:RegisterEvent("QUEST_ACCEPTED")
events:RegisterEvent("QUEST_REMOVED")
events:RegisterEvent("QUEST_TURNED_IN")
events:RegisterEvent("QUEST_LOG_UPDATE")
events:RegisterEvent("QUESTLINE_UPDATE")
events:RegisterEvent("GOSSIP_SHOW")
events:SetScript("OnEvent", function(_, event)
    if event == "GOSSIP_SHOW" then
        CaptureGossipFrequencies()
    end
    RefreshMapFrequencyCache()
    UpdateTabs()
end)

mainFrame:HookScript("OnShow", function()
    RefreshMapFrequencyCache()
    UpdateTabs()
end)

CaptureGossipFrequencies()
RefreshMapFrequencyCache()
UpdateTabs()
